class AuthenticationError(Exception):
	pass

class IneligibleError(Exception):
	pass

class InvalidAppIdError(Exception):
	pass

class InvalidAppSecretError(Exception):
	pass
